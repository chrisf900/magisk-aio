#!/system/bin/sh

# This script will be executed in late_start service mode
# More info in the main Magisk thread