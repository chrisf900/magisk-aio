#!/system/bin/sh

# This script will be executed in post-fs mode
# More info in the main Magisk thread